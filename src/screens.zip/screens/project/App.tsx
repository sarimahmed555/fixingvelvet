import React from 'react';
import { Notifications } from './src/screens/Notifications';

const App: React.FC = () => {
  return <Notifications />;
};

export default App;